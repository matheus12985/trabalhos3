﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoTep
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        conexaobd bd = new conexaobd();
        string sql;
        DateTime data;
        public void limpar()
        {
            txtmatricula.Clear();
            txtnome.Clear();
            txtnota.Clear();
            cbxsexo.SelectedIndex = -1;
            dtdata.Text = DateTime.Now.ToString();
        }
        public void listar()
        {
            sql = "Select * from alunos";
            dgtlista.DataSource = bd.consultar(sql);
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtnome_TextChanged(object sender, EventArgs e)
        {

        }

        private void dtdata_ValueChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            listar();
        }

        private void btnovo_Click(object sender, EventArgs e)
        {
            data = DateTime.Parse(dtdata.Text);

            sql = string.Format("insert into alunos values (null,'{0}','{1}','{2}','{3}');",txtnome.Text,data.ToString("yyyy-MM-dd"),cbxsexo.Text,txtnota.Text);
            bd.alterardados(sql);
            MessageBox.Show("Aluno cadastrado com sucesso","Aluno",MessageBoxButtons.OK,MessageBoxIcon.Information);
            limpar();
            listar();
        }

        private void btbuscar_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            sql = string.Format("select * from alunos where matricula = '{0}';",txtmatricula.Text);
            dt = bd.consultar(sql);
            if (dt.Rows.Count > 0)
            {
                txtmatricula.Text = dt.Rows[0]["matricula"].ToString();
                txtnome.Text = dt.Rows[0]["nome"].ToString();
                txtnota.Text = dt.Rows[0]["nota"].ToString();
                cbxsexo.Text = dt.Rows[0]["sexo"].ToString();
                dtdata.Text = dt.Rows[0]["dt_nasc"].ToString();
                dgtlista.DataSource = bd.consultar(sql);
            }
            else
            {
                MessageBox.Show("Aluno não cadastrado!", "Aluno", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btalterar_Click(object sender, EventArgs e)
        {
            data = DateTime.Parse(dtdata.Text);

            sql = string.Format("update alunos set nome = '{0}', nota = '{1}', dt_nasc = '{2}', sexo = '{3}' where matricula = '{4}';", txtnome.Text, txtnota.Text, data.ToString("yyyy-MM-dd"), cbxsexo.Text, txtmatricula.Text);
            bd.alterardados(sql);
            MessageBox.Show("Aluno alterado com sucesso", "Aluno", MessageBoxButtons.OK, MessageBoxIcon.Information);
            limpar();
            listar();
        }

        private void btexcluir_Click(object sender, EventArgs e)
        {
            data = DateTime.Parse(dtdata.Text);

            sql = string.Format("delete from alunos where matricula = '{0}';", txtmatricula.Text);
            bd.alterardados(sql);
            MessageBox.Show("Aluno deletado com sucesso", "Aluno", MessageBoxButtons.OK, MessageBoxIcon.Information);
            limpar();
            listar();
        }

        private void btvoltar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
