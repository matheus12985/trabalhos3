﻿namespace ProjetoTep
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtmatricula = new System.Windows.Forms.TextBox();
            this.txtnome = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.dtdata = new System.Windows.Forms.DateTimePicker();
            this.cbxsexo = new System.Windows.Forms.ComboBox();
            this.txtnota = new System.Windows.Forms.TextBox();
            this.dgtlista = new System.Windows.Forms.DataGridView();
            this.btnovo = new System.Windows.Forms.Button();
            this.btbuscar = new System.Windows.Forms.Button();
            this.btalterar = new System.Windows.Forms.Button();
            this.btexcluir = new System.Windows.Forms.Button();
            this.btvoltar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgtlista)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(25, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Matricula";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(279, 8);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Nome";
            // 
            // txtmatricula
            // 
            this.txtmatricula.Location = new System.Drawing.Point(25, 38);
            this.txtmatricula.Name = "txtmatricula";
            this.txtmatricula.Size = new System.Drawing.Size(160, 26);
            this.txtmatricula.TabIndex = 2;
            this.txtmatricula.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // txtnome
            // 
            this.txtnome.Location = new System.Drawing.Point(279, 38);
            this.txtnome.Name = "txtnome";
            this.txtnome.Size = new System.Drawing.Size(523, 26);
            this.txtnome.TabIndex = 3;
            this.txtnome.TextChanged += new System.EventHandler(this.txtnome_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(25, 88);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(154, 20);
            this.label3.TabIndex = 4;
            this.label3.Text = "Data de Nascimento";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(429, 87);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 20);
            this.label4.TabIndex = 5;
            this.label4.Text = "Sexo";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(668, 88);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(43, 20);
            this.label5.TabIndex = 6;
            this.label5.Text = "Nota";
            // 
            // dtdata
            // 
            this.dtdata.Location = new System.Drawing.Point(25, 120);
            this.dtdata.Name = "dtdata";
            this.dtdata.Size = new System.Drawing.Size(333, 26);
            this.dtdata.TabIndex = 7;
            this.dtdata.ValueChanged += new System.EventHandler(this.dtdata_ValueChanged);
            // 
            // cbxsexo
            // 
            this.cbxsexo.FormattingEnabled = true;
            this.cbxsexo.Items.AddRange(new object[] {
            "M",
            "F",
            "O",
            "N"});
            this.cbxsexo.Location = new System.Drawing.Point(429, 118);
            this.cbxsexo.Name = "cbxsexo";
            this.cbxsexo.Size = new System.Drawing.Size(161, 28);
            this.cbxsexo.TabIndex = 8;
            // 
            // txtnota
            // 
            this.txtnota.Location = new System.Drawing.Point(668, 120);
            this.txtnota.Name = "txtnota";
            this.txtnota.Size = new System.Drawing.Size(134, 26);
            this.txtnota.TabIndex = 9;
            // 
            // dgtlista
            // 
            this.dgtlista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgtlista.Location = new System.Drawing.Point(25, 169);
            this.dgtlista.Name = "dgtlista";
            this.dgtlista.RowHeadersWidth = 62;
            this.dgtlista.RowTemplate.Height = 28;
            this.dgtlista.Size = new System.Drawing.Size(777, 213);
            this.dgtlista.TabIndex = 10;
            // 
            // btnovo
            // 
            this.btnovo.Location = new System.Drawing.Point(25, 412);
            this.btnovo.Name = "btnovo";
            this.btnovo.Size = new System.Drawing.Size(113, 63);
            this.btnovo.TabIndex = 11;
            this.btnovo.Text = "Novo";
            this.btnovo.UseVisualStyleBackColor = true;
            this.btnovo.Click += new System.EventHandler(this.btnovo_Click);
            // 
            // btbuscar
            // 
            this.btbuscar.Location = new System.Drawing.Point(191, 412);
            this.btbuscar.Name = "btbuscar";
            this.btbuscar.Size = new System.Drawing.Size(113, 63);
            this.btbuscar.TabIndex = 12;
            this.btbuscar.Text = "Buscar";
            this.btbuscar.UseVisualStyleBackColor = true;
            this.btbuscar.Click += new System.EventHandler(this.btbuscar_Click);
            // 
            // btalterar
            // 
            this.btalterar.Location = new System.Drawing.Point(357, 412);
            this.btalterar.Name = "btalterar";
            this.btalterar.Size = new System.Drawing.Size(113, 63);
            this.btalterar.TabIndex = 13;
            this.btalterar.Text = "Alterar";
            this.btalterar.UseVisualStyleBackColor = true;
            this.btalterar.Click += new System.EventHandler(this.btalterar_Click);
            // 
            // btexcluir
            // 
            this.btexcluir.Location = new System.Drawing.Point(527, 412);
            this.btexcluir.Name = "btexcluir";
            this.btexcluir.Size = new System.Drawing.Size(113, 63);
            this.btexcluir.TabIndex = 14;
            this.btexcluir.Text = "Excluir";
            this.btexcluir.UseVisualStyleBackColor = true;
            this.btexcluir.Click += new System.EventHandler(this.btexcluir_Click);
            // 
            // btvoltar
            // 
            this.btvoltar.Location = new System.Drawing.Point(689, 412);
            this.btvoltar.Name = "btvoltar";
            this.btvoltar.Size = new System.Drawing.Size(113, 63);
            this.btvoltar.TabIndex = 15;
            this.btvoltar.Text = "Voltar";
            this.btvoltar.UseVisualStyleBackColor = true;
            this.btvoltar.Click += new System.EventHandler(this.btvoltar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(821, 487);
            this.Controls.Add(this.btvoltar);
            this.Controls.Add(this.btexcluir);
            this.Controls.Add(this.btalterar);
            this.Controls.Add(this.btbuscar);
            this.Controls.Add(this.btnovo);
            this.Controls.Add(this.dgtlista);
            this.Controls.Add(this.txtnota);
            this.Controls.Add(this.cbxsexo);
            this.Controls.Add(this.dtdata);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtnome);
            this.Controls.Add(this.txtmatricula);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Cadastro de Alunos";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgtlista)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtmatricula;
        private System.Windows.Forms.TextBox txtnome;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DateTimePicker dtdata;
        private System.Windows.Forms.ComboBox cbxsexo;
        private System.Windows.Forms.TextBox txtnota;
        private System.Windows.Forms.DataGridView dgtlista;
        private System.Windows.Forms.Button btnovo;
        private System.Windows.Forms.Button btbuscar;
        private System.Windows.Forms.Button btalterar;
        private System.Windows.Forms.Button btexcluir;
        private System.Windows.Forms.Button btvoltar;
    }
}

